var allParty = [],allPartyValue = [], arrOfHC = [], chartArray = [],sumAllPartyValue = 0,sumAllPartyValueLead = 0, sumAllPartyValueWon = 0, stateWiseResDropDef = 33;
var arrOfHC=0,totalWardsValue=0,trsPartyValue=0,incPartyValue=0,bjpPartyValue=0,mimPartyValue=0,otherPartyValue=0;
var stateWiseResUrl = "";
var stateConstUrl = "";
var getName;

var appData = {
    apiConfig: {
        baseURL: 'https://mcapi.etvbharat.com/web_api/website/muncorp_ts20_website/',
        suffixes: {
            getCorp: 'getcorporations.php',
            getMunicipal: 'getmunicipalities.php',
            municipalResults: 'municipalwise_winning_candidate.php?language=english&municipal=',
            corpResults: 'corporationwise_winning_candidate.php?language=english&corporation=',
            corpPartyWiseTally: 'corporationwise_party_tally.php?language=english',
            municipalPartyWiseTally: 'muncipalwise_party_tally.php?language=english'

        },
    },
}

function getJSON(url, successCallback) {
    $.getJSON(url, function(response) {
        successCallback(response);
    });
}

function getLiveStreamURL()
{
    // http://13.127.2.47/web_api/website/partywise_wonlead_total.php?language=ENGLISH&notif_id=11
    var parentURL = document.referrer;
    //var parentURL = 'https://www.etvbharat.com/bengali/kerala';
    var temp = parentURL.split('/');
    var lang = temp[4];
    var stremingURLs = {
        "andhra-pradesh":"https://d1lqvjyfwvyj07.cloudfront.net/out/v1/d54651fa806648719a92727a661fa0d0/ETVB_CF_AP_NewsTime.m3u8",
        "assam":"https://etvbharatlive8.akamaized.net/hls/live/710674/assam/index.m3u8",
        "bihar":"https://etvbharatlive3.akamaized.net/hls/live/710666/bihar/index.m3u8",
        "chhattisgarh":"https://d2lkimnyxc1ji8.cloudfront.net/out/v1/cadefd8c8bff49d4a3ef38c1b3bf6a31/ETVB_CF_CG_NewsTime.m3u8",
        "delhi":"https://d29q6tdfij96f1.cloudfront.net/out/v1/94b12003316c4d6c9721a1508b0d1bac/ETVB_CF_DL_NewsTime.m3u8",
        "gujarat":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/04fee298badd4ea087aa4b68f4a8c034/ETVB_BG_GJ_NewsTime.m3u8",
        "haryana":"https://d3ejgzjh1qxqqq.cloudfront.net/out/v1/6d44b1b671d548a6bc95edea325b8413/ETVB_CF_HR_NewsTime.m3u8",
        "himachal-pradesh":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/a64cd2ff63e14792a4783b6d458ed5ab/ETVB_BG_HP_NewsTime.m3u8",
        "jharkhand":"https://etvbharatlive2.akamaized.net/hls/live/710296/jharkhand/index.m3u8",
        "jammu-and-kashmir":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "karnataka":"https://etvbharatlive5.akamaized.net/hls/live/710671/kannada/index.m3u8",
        "kerala":"https://etvbharatlive7.akamaized.net/hls/live/710673/kerala/index.m3u8",
        "maharashtra":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/bd4b06bb4ff24d938c3942ee89b1126d/ETVB_BG_MH_NewsTime.m3u8",
        "madhya-pradesh":"https://d1i5fpe095d43k.cloudfront.net/out/v1/16a901263bf7402e9cb7ff4b94fa5bfd/ETVB_CF_MP_NewsTime.m3u8",
        "english":"https://d5i7xalz199bi.cloudfront.net/out/v1/770fb77abc5d4ef487fc8b8b38d60510/ETVB_CF_EN_NewsTime.m3u8",
        "urdu":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "odisha":"https://etvbharatlive.akamaized.net/hls/live/707618/odisha/index.m3u8",
        "punjab":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/68eee6155d904f199aad20af043f9003/ETVB_BG_PB_NewsTime.m3u8",
        "rajasthan":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/0703d0f945c64e15aef72cd11fd54668/ETVB_BG_RJ_NewsTime.m3u8",
        "tamil-nadu":"https://dfae28bzu51al.cloudfront.net/out/v1/ee7ba7ef70fc4005a3992a2c0e8336aa/ETVB_CF_TN_NewsTime.m3u8",
        "telangana":"https://d1q8rg3smbsux8.cloudfront.net/out/v1/c7849afc704b478fb86a9e2caac3854a/ETVB_CF_TS_NewsTime.m3u8",
        "uttar-pradesh":"https://etvbharatlive6.akamaized.net/hls/live/710672/uttarPradesh/index.m3u8",
        "uttarakhand":"https://etvbharatlive1.akamaized.net/hls/live/710294/uttarakhand/index.m3u8",
        "west-bengal":"https://etvbharatlive9.akamaized.net/hls/live/710675/westBengal/index.m3u8"
    }
    if(lang)
    {
        var url = stremingURLs[lang.toLowerCase()];
        if(url)
            return url;
            console.log(url);
    }
    return stremingURLs['telangana'];
 }



function getLanguageState() {
    
    getJSON(appData.apiConfig.baseURL+appData.apiConfig.suffixes.getMunicipal, function(getStatesresult) {
        renderLanguageState(createDropdownHTML(getStatesresult, 'state_id', 'state_name'));
         renderConstituencyState(createDropdownHTML(getStatesresult, 'muncipal_id', 'muncipal_name'));
    });
    getJSON(appData.apiConfig.baseURL+appData.apiConfig.suffixes.getCorp, function(getcorpresult){
        renderConstituencyState1(createDropdownHTML(getcorpresult, 'corporation_id', 'corporation_name'));
    })
}


function createDropdownHTML(incomingData, idKey, displayKey) {
    var option = "";
    for (var l = 0; l <= incomingData.results.length - 1; l++) {
        option += '<option value="' + incomingData.results[l][idKey] + '">' + incomingData.results[l][displayKey] + '</option>';
    }
    return option;
}


function renderConstituencyState(option) {
    document.getElementById('constituencyWise');
    $("#constituencyWise").empty();
    document.getElementById('constituencyWise').innerHTML = option;
    $(".constit-drop option").each(function() {
        if ($(this).text() == "")
            $(this).attr("selected", "selected");
    });
}




function renderConstituencyState1(option) {
    document.getElementById('constituencyWise3');
    $("#constituencyWise3").empty();
    document.getElementById('constituencyWise3').innerHTML = option;
    $(".constit-drop option").each(function() {
        if ($(this).text() == "")
            $(this).attr("selected", "selected");
    });
}


 function renderLanguageState(ele,option) {
   
    ele.innerHTML = option;
    var exists = false;
    $(ele).find('option').each(function(){
        if (this.value == stateWiseResDropDef) {
            exists = true;
            return false;
        }
    });
    if(exists){
    $(ele).val(stateWiseResDropDef);
    }
    $(ele).trigger("change");
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}


function getmunicipalTally() {
    //highchart
    //Tally Lok Sabha
    getJSON(appData.apiConfig.baseURL+appData.apiConfig.suffixes.municipalPartyWiseTally, function(result) {
        console.log(chartArray);
        var arrOfHC=0,trsPartyValue=0,incPartyValue=0,bjpPartyValue=0,mimPartyValue=0,otherPartyValue=0;
        for (var i = 0; i <= result.totalresults.length - 1; i++) {
            var partyInfoArr = result.totalresults[i];
            chartArray.push([partyInfoArr["muncipal_name"]]);
            trsPartyValue += parseInt(partyInfoArr["partyname_trs"]);
            incPartyValue += parseInt(partyInfoArr["partyname_inc"]);
            bjpPartyValue += parseInt(partyInfoArr["partyname_bjp"]);
            mimPartyValue += parseInt(partyInfoArr["partyname_mim"]);
            otherPartyValue += parseInt(partyInfoArr["others"]);
        }
        var arrOfHC = [chartArray[0],chartArray[7],chartArray[5],chartArray[6],chartArray[4],chartArray[2],chartArray[3],chartArray[1]];
        // renderLokSabhaChart(arrOfHC, trsPartyValue,incPartyValue,bjpPartyValue,mimPartyValue,otherPartyValue);
        $("#sumTrsM").html(trsPartyValue);
        $("#sumIncM").html(incPartyValue);
        $("#sumBjpM").html(bjpPartyValue);
        $("#sumMimM").html(mimPartyValue);
        $("#sumOtherM").html(otherPartyValue);
    });
}
function getmunicipalParty() {
    getJSON(appData.apiConfig.baseURL+appData.apiConfig.suffixes.municipalPartyWiseTally, function(result) {
        console.log(chartArray);
        CombinedHTMLTable='';
        var tr;
        for (var j = 0; j <= result.totalresults.length - 1; j++) {
        var tr = "<tr>" + "<td>" + result.totalresults[j]['muncipal_name'] + "</td>" +
        // "<td>" + result.totalresults[j]['totalwards'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_trs'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_inc'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_bjp'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_mim'] + "</td>" +
        "<td>" + result.totalresults[j]['others'] + "</td>" + "</tr>";
        CombinedHTMLTable = CombinedHTMLTable + tr;
    // stateWiseTotal = stateWiseTotal + parseInt(result.totalresults[j]['Total']);
        }
        $("#municipalPartyData").html(CombinedHTMLTable);
        $("#tdSearch2").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#municipaltally tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                // $(this).css('background-color','AliceBlue ')
            });
        });
    });
}


function getCorpTally() {
    //highchart
    //Tally Lok Sabha
    // const tbody = document.querySelector("#corptally > tbody");
    getJSON(appData.apiConfig.baseURL+appData.apiConfig.suffixes.corpPartyWiseTally, function(result) {
        
        console.log(chartArray);
        var arrOfHC=0,trsPartyValue=0,incPartyValue=0,bjpPartyValue=0,mimPartyValue=0,otherPartyValue=0;
        for (var i = 0; i <= result.totalresults.length - 1; i++) {
            var partyInfoArr = result.totalresults[i];
            chartArray.push([partyInfoArr["corporation_name"]]);
            trsPartyValue += parseInt(partyInfoArr["partyname_trs"]);
            incPartyValue += parseInt(partyInfoArr["partyname_inc"]);
            bjpPartyValue += parseInt(partyInfoArr["partyname_bjp"]);
            mimPartyValue += parseInt(partyInfoArr["partyname_mim"]);
            otherPartyValue += parseInt(partyInfoArr["others"]);
        }
        var arrOfHC = [chartArray[0],chartArray[7],chartArray[5],chartArray[6],chartArray[4],chartArray[2],chartArray[3],chartArray[1]];
        // renderLokSabhaChart(arrOfHC, trsPartyValue,incPartyValue,bjpPartyValue,mimPartyValue,otherPartyValue);
        $("#sumTrsCorp").html(trsPartyValue);
        $("#sumIncCorp").html(incPartyValue);
        $("#sumBjpCorp").html(bjpPartyValue);
        $("#sumMimCorp").html(mimPartyValue);
        $("#sumOtherCorp").html(otherPartyValue);

    });
}
function getCorpParty() {
    getJSON(appData.apiConfig.baseURL+appData.apiConfig.suffixes.corpPartyWiseTally, function(result) {
        console.log(chartArray);
        CombinedHTMLTable='';
        var tr;getmunicipalParty()
        for (var j = 0; j <= result.totalresults.length - 1; j++) {
        var tr = "<tr>" + "<td>" + result.totalresults[j]['corporation_name'] + "</td>" +
        // "<td>" + result.totalresults[j]['totalwards'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_trs'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_inc'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_bjp'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_mim'] + "</td>" +
        "<td>" + result.totalresults[j]['others'] + "</td>" + "</tr>";
        CombinedHTMLTable = CombinedHTMLTable + tr;
    // stateWiseTotal = stateWiseTotal + parseInt(result.totalresults[j]['Total']);
        }
        $("#corpPartyData").html(CombinedHTMLTable);
        $("#tdSearch1").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#corptally tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                // $(this).css('background-color','AliceBlue ')
            });
        });
    });
}





function onChangeStates(val) {
    if(val)
    {
    $('#state-tg').empty();
    if ($.isNumeric(val)) {
        stateWiseResUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateVIP + val;
    }
    stateResBind(stateWiseResUrl);
    getVipPerson();
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}
}
function getLiveDebateState() {
        $('.live-name').text("Live Debate");
         var test = 'https://dgt6f5s87pgbo.cloudfront.net/out/v1/dd6e383c67c44d20a41a358679edd9c7/ETVB_CF_JK_Live3.m3u8';
        var player='<iframe style="width:100%;" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';
        $('#test-player').html(player);
        document.getElementById("livenews").style.color = "white";
        document.getElementById("livedebate").style.color = "red";
        // $('.icon').click(function() {
        //     $(this).children("i").attr("class", "fa fa-circle blink_text") ;
        // }); 
    }

function getLiveState() {
        $('.live-name').text("Live News");
    // $('.circle').addClass("fa fa-circle blink_text")
        var test =getLiveStreamURL();
        var player='<iframe style="width:100%;" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';

        $('#test-player').html(player);
        // document.getElementById("livenews").style.color = "red";
        // document.getElementById("livedebate").style.color = "white";
        $('.icon').children("i").attr("class", "fa fa-circle blink_text") ;
         
    }
function onChangeConstWise(val) {


    
    if ($.isNumeric(val)) {
        stateConstUrl = appData.apiConfig.baseURL+appData.apiConfig.suffixes.municipalResults + val;
    } else {
        stateConstUrl = appData.apiConfig.baseURL+appData.apiConfig.suffixes.municipalResults+180;
    }
    constiResBind(stateConstUrl);
}

function onChangeConstWise3(val) {
    if ($.isNumeric(val)) {
        stateConstUrl3 = appData.apiConfig.baseURL+appData.apiConfig.suffixes.corpResults+ val;
    } else {
        stateConstUrl3 = appData.apiConfig.baseURL+appData.apiConfig.suffixes.corpResults+7;
    }
    constiResBind1(stateConstUrl3);
}



function totalCount(successdata, stateWiseTotal){
    var totalCountStateWise = successdata.results.PartyInfo[0].TotalConstituency;
    document.getElementById("stateWiseTotal").textContent = parseInt(stateWiseTotal) +"/"+ parseInt(totalCountStateWise);
}

function callAPiEveryMinute(){
    corpUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.municipalResults+ $('#constituencyWise').val();
    municipalUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.corpResults+ $('#constituencyWise3').val();;
    constiResBind(corpUrl);
    constiResBind1(municipalUrl);
    
    

    
}
function constiResBind1(url) {
    const tbody = document.querySelector("#AP_Constituency3 > tbody");
    $.getJSON(url,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var tr;
            for (var j = 0; j <= successdata.results.length - 1; j++) {
                if (successdata.results[j]['status'].toLowerCase() == "lead") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='leading-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else if (successdata.results[j]['status'].toLowerCase() == "won") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='won-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else if (successdata.results[j]['status'].toLowerCase() == "lost") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='lost-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='trailing-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
            }
            // $("#onChangeConstWise").html(CombinedHTML);
            $("#constituency_tbody3").html(CombinedHTMLTable);
            $("#tdSearch3").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#AP_Constituency3 tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    // $(this).css('background-color','AliceBlue ')
                });
            });
        });
}

function constiResBind(url) {
    const tbody = document.querySelector("#AP_Constituency > tbody");
    $.getJSON(url,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var tr;
            for (var j = 0; j <= successdata.results.length - 1; j++) {
                if (successdata.results[j]['status'].toLowerCase() == "lead") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='leading-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else if (successdata.results[j]['status'].toLowerCase() == "won") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='won-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else if (successdata.results[j]['status'].toLowerCase() == "lost") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='lost-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='trailing-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
            }
            // $("#onChangeConstWise").html(CombinedHTML);
            $("#constituency_tbody").html(CombinedHTMLTable);
            $("#tdSearch").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#AP_Constituency tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                    // $(this).css('background-color','AliceBlue ')
                });
            });
        });
}


$(document).ready(function() {
    
    getLanguageState();
    onChangeConstWise();
    onChangeConstWise3();
    getCorpParty();
    getmunicipalParty()
    getCorpTally();
    getmunicipalTally();
   
    var test = getLiveStreamURL();
    var player='<iframe style="width:100%;" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';
    // // var player2='<iframe style="width:100%;" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';
    $('#test-player').html(player);
    // // $('#test-player2').html(player2);
    $("#divPlayer").attr('src' , test);
    $('.icon').children("i").attr("class", "fa fa-circle blink_text") ;
    // document.getElementById("livenews").style.color = "red";

    setInterval(callAPiEveryMinute, 60000);
    setInterval(function(){
        getCorpParty();
        getmunicipalTally();
        getCorpTally();
        getmunicipalParty();
    },20000);
});