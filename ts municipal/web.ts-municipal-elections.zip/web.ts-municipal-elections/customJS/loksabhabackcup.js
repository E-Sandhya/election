var allParty = [],allPartyValue = [], arrOfHC = [], chartArray = [],sumAllPartyValue = 0,sumAllPartyValueLead = 0, sumAllPartyValueWon = 0, stateWiseResDropDef = 33;
var stateWiseResUrl = "http://13.127.2.47/web_api/website/partywise_wonlead_total.php?language=ENGLISH&notif_id=11";
var stateConstUrl = "http://13.127.2.47/web_api/website/statewise_const_tally.php?language=ENGLISH&notif_id=11";
var getName;

var appData = {
    apiConfig: {
        baseURL: 'http://13.127.2.47/web_api/website/',
        suffixes: {
            getState: 'getStates.php',
            // partyWiseResultsCorp: 'muncorp_ts20_website/partywise_wonlead_corp.php',
            // partyWiseResultsM: 'muncorp_ts20_website/partywise_wonlead_munc.php',
            corpPartyTally: 'muncorp_ts20_website/corporationwise_party_tally.php?language=english',
            mPartyTally: 'muncorp_ts20_website/muncipalwise_party_tally.php?language=english',
            nationalPerson: 'nationalvipcandidates_wonlead.php?language=ENGLISH&notif_id=11',
            resultType: '?electionType='
        },
    },
}

var corpPartyTallyConfig = {
    "ajax": {
        url: appData.apiConfig.baseURL + appData.apiConfig.suffixes.corpPartyTally,
        dataSrc: 'totalresults'
    },
    "bPaginate": false,
    "aaSorting": [],
    "columns": [{
        "data": "corporation_name"
    },
    {
        "data": "partyname_trs"
    },
    {
        "data": "partyname_inc"
    },
    {
        "data": "partyname_bjp"
    },
    {
        "data": "partyname_mim"
    },
    {
        "data": "others"
    }
  ]
};

var mPartyTallyConfig = {
    "ajax": {
        url: appData.apiConfig.baseURL + appData.apiConfig.suffixes.mPartyTally,
        dataSrc: 'totalresults'
    },
    "bPaginate": false,
    "aaSorting": [],
    "columns": [{
        "data": "muncipal_name"
    },
    {
        "data": "partyname_trs"
    },
    {
        "data": "partyname_inc"
    },
    {
        "data": "partyname_bjp"
    },
    {
        "data": "partyname_mim"
    },
    {
        "data": "others"
    }
  ]
};

// var corpResultConfig = {
//     "ajax": {
//         url: appData.apiConfig.baseURL + appData.apiConfig.suffixes.partyWiseResultsCorp,
//         dataSrc: 'results'
//     },
//     "bPaginate": false,
//     "aaSorting": [],
//     "columns": [{
//         "data": "party_name"
//     },
//     {
//         "data": "Seats Contested"
//     },
//     {
//         "data": "lead"
//     },
//     {
//         "data": "won"
//     },
//     {
//         "data": "total"
//     },
//     {
//         "data": "gain+"
//     },
//     {
//         "data": "loss-"
//     }
//   ]
// };

// var mResultConfig = {
//     "ajax": {
//         url:appData.apiConfig.baseURL + appData.apiConfig.suffixes.partyWiseResultsM,
//         dataSrc: 'results'
//     },
//     "bPaginate": false,
//     "aaSorting": [],
//     "destroy": true,
//     "columns": [{
//         "data": "party_name"
//     },
//     {
//         "data": "Seats Contested"
//     },
//     {
//         "data": "lead"
//     },
//     {
//         "data": "won"
//     },
//     {
//         "data": "total"
//     },
//     {
//         "data": "gain+"
//     },
//     {
//         "data": "loss-"
//     }
//     ]
// };


function getJSON(url, successCallback) {
    $.getJSON(url, function(response) {
        successCallback(response);
    });
}

function getLiveStreamURL()
{
    var parentURL = document.referrer;
    //var parentURL = 'https://www.etvbharat.com/bengali/kerala';
    var temp = parentURL.split('/');
    var lang = temp[4];
    var stremingURLs = {
        "andhra-pradesh":"https://d1lqvjyfwvyj07.cloudfront.net/out/v1/d54651fa806648719a92727a661fa0d0/ETVB_CF_AP_NewsTime.m3u8",
        "assam":"https://etvbharatlive8.akamaized.net/hls/live/710674/assam/index.m3u8",
        "bihar":"https://etvbharatlive3.akamaized.net/hls/live/710666/bihar/index.m3u8",
        "chhattisgarh":"https://d2lkimnyxc1ji8.cloudfront.net/out/v1/cadefd8c8bff49d4a3ef38c1b3bf6a31/ETVB_CF_CG_NewsTime.m3u8",
        "delhi":"https://d29q6tdfij96f1.cloudfront.net/out/v1/94b12003316c4d6c9721a1508b0d1bac/ETVB_CF_DL_NewsTime.m3u8",
        "gujarat":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/04fee298badd4ea087aa4b68f4a8c034/ETVB_BG_GJ_NewsTime.m3u8",
        "haryana":"https://d3ejgzjh1qxqqq.cloudfront.net/out/v1/6d44b1b671d548a6bc95edea325b8413/ETVB_CF_HR_NewsTime.m3u8",
        "himachal-pradesh":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/a64cd2ff63e14792a4783b6d458ed5ab/ETVB_BG_HP_NewsTime.m3u8",
        "jharkhand":"https://etvbharatlive2.akamaized.net/hls/live/710296/jharkhand/index.m3u8",
        "jammu-and-kashmir":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "karnataka":"https://etvbharatlive5.akamaized.net/hls/live/710671/kannada/index.m3u8",
        "kerala":"https://etvbharatlive7.akamaized.net/hls/live/710673/kerala/index.m3u8",
        "maharashtra":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/bd4b06bb4ff24d938c3942ee89b1126d/ETVB_BG_MH_NewsTime.m3u8",
        "madhya-pradesh":"https://d1i5fpe095d43k.cloudfront.net/out/v1/16a901263bf7402e9cb7ff4b94fa5bfd/ETVB_CF_MP_NewsTime.m3u8",
        "english":"https://d5i7xalz199bi.cloudfront.net/out/v1/770fb77abc5d4ef487fc8b8b38d60510/ETVB_CF_EN_NewsTime.m3u8",
        "urdu":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "odisha":"https://etvbharatlive.akamaized.net/hls/live/707618/odisha/index.m3u8",
        "punjab":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/68eee6155d904f199aad20af043f9003/ETVB_BG_PB_NewsTime.m3u8",
        "rajasthan":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/0703d0f945c64e15aef72cd11fd54668/ETVB_BG_RJ_NewsTime.m3u8",
        "tamil-nadu":"https://dfae28bzu51al.cloudfront.net/out/v1/ee7ba7ef70fc4005a3992a2c0e8336aa/ETVB_CF_TN_NewsTime.m3u8",
        "telangana":"https://d1q8rg3smbsux8.cloudfront.net/out/v1/c7849afc704b478fb86a9e2caac3854a/ETVB_CF_TS_NewsTime.m3u8",
        "uttar-pradesh":"https://etvbharatlive6.akamaized.net/hls/live/710672/uttarPradesh/index.m3u8",
        "uttarakhand":"https://etvbharatlive1.akamaized.net/hls/live/710294/uttarakhand/index.m3u8",
        "west-bengal":"https://etvbharatlive9.akamaized.net/hls/live/710675/westBengal/index.m3u8"
    }
    if(lang)
    {
        var url = stremingURLs[lang.toLowerCase()];
        if(url)
            return url;
            console.log(url);
    }
    return stremingURLs['english'];
}

// LiveNews function

function getLiveStateNews(){
    var test =getLiveStreamURL();
    var player='<iframe style="width: 100%; height: 315px" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';    $('#test-player').html(player);
    $("#divPlayer").attr('src' , test);
    document.getElementById("livenews").style.color = "red";
    document.getElementById("livedebate").style.color = "white";
}

// LiveDebate function

function getLiveDebate() {
    var test1 ='https://dgt6f5s87pgbo.cloudfront.net/out/v1/dd6e383c67c44d20a41a358679edd9c7/ETVB_CF_JK_Live3.m3u8';
    var player='<iframe style="width:100%; height:315px;" id="live-player" class="liveplayer" allowfullscreen="true" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test1+'&amp;thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&amp;autoplay=true&amp;mute=true&amp;content_type=live&amp;content_id=keralaml20181012194643400&amp;v=0.007124921779837923&amp;comscorec3=23&amp;state=kerala&amp;language=malayalam&amp;daistream=true" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl=https://etvbharatlive7.akamaized.net/hls/live/710673/kerala/index.m3u8&amp;thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&amp;autoplay=true&amp;mute=true&amp;content_type=live&amp;content_id=keralaml20181012194643400&amp;v=0.007124921779837923&amp;comscorec3=23&amp;state=kerala&amp;language=malayalam&amp;daistream=true"></iframe>';
    $('#test-player').html(player);
    $("#divPlayer").attr('src' , test1);
    document.getElementById("livedebate").style.color = "red";
    document.getElementById("livenews").style.color = "white";
}

function getLanguageState(value, stateDdlID) {
    var ele = document.getElementById(stateDdlID);
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.getState+'?electionType='+value, function(getStatesresult) {
        renderLanguageState(ele,createDropdownHTML(getStatesresult, 'state_id', 'state_name'));
    });
}

function createDropdownHTML(incomingData, idKey, displayKey) {
    var option = "";
    for (var l = 0; l <= incomingData.results.length - 1; l++) {
        option += '<option value="' + incomingData.results[l][idKey] + '">' + incomingData.results[l][displayKey] + '</option>';
    }
    return option;
}

function renderLanguageState(ele,option) {
    ele.innerHTML = option;
    var exists = false;
    $(ele).find('option').each(function(){
        if (this.value == stateWiseResDropDef) {
            exists = true;
            return false;
        }
    });
    if(exists){
    $(ele).val(stateWiseResDropDef);
    }
    $(ele).trigger("change");
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}

//Jharkhand tally function

function renderLokSabhaChart(arrOfHC, sumAllPartyValue, sumAllPartyValueLead, sumAllPartyValueWon) {
    $("#sumAllPartyValueLead").html(sumAllPartyValueLead);
    $("#sumAllPartyValueWon").html(sumAllPartyValueWon);
    $(".sumAllPartyValue").html(sumAllPartyValue+"/"+"81");


    Highcharts.chart('tally_lok_sabha', {
        chart: {
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: '',
            align: 'center',
            verticalAlign: 'middle',
            y: 50
        },
        tooltip: {
            pointFormat: '<b>{point.percentage:.1f}</b>'
        },
        plotOptions: {
            pie: {
                dataLabels: {
                    enabled: true,
                    distance: -70,
                    style: {
                        fontWeight: 'bold',
                        color: 'black'
                    }
                },
                startAngle: -90,
                endAngle: 90,
                center: ['50%', '50%']
            }
        },

        colors: ["#ff5429", "#00311f", "#128548", "#0255c7", "#ff0000", "#9f0606", "#db7b03", "#41ac38", "#8d8d8d", "#27a4ff"],
        series: [{
            type: 'pie',
            name: '',
            innerSize: '50%',
            data: arrOfHC
        }]
    });
};

//Jharkhand tally function
function getLokSabhaHighChart() {
    //highchart
    //Tally Jharkhand
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.partyWiseResultsCorp, function(result) {
        console.log(chartArray);
        var sumAllPartyValue =0, sumAllPartyValueWon=0, sumAllPartyValueLead=0;
        for (var i = 0; i <= result.results.length - 1; i++) {
            var partyInfoArr = result.results[i];
            chartArray.push([partyInfoArr["party_name"], parseInt(partyInfoArr["total"])]);
            sumAllPartyValue += parseInt(partyInfoArr["total"]);
            sumAllPartyValueLead += parseInt(partyInfoArr["lead"]);
            sumAllPartyValueWon += parseInt(partyInfoArr["won"]);
        }
        var arrOfHC = [chartArray[0],chartArray[7],chartArray[5],chartArray[6],chartArray[4],chartArray[2],chartArray[3],chartArray[1]];
        renderLokSabhaChart(arrOfHC, sumAllPartyValue, sumAllPartyValueLead, sumAllPartyValueWon);
    });
}
// Jharkhand VIP Candidates
function getNationalPerson() {
    $.getJSON( appData.apiConfig.baseURL+appData.apiConfig.suffixes.stateVIP, function(success) {
    var nationalPerson = success.results;
    var CombinedHTML = '';
    for (var i = 0; i <= nationalPerson.length - 1; i++) {
    var personailty = {
    leadings: nationalPerson[i]['status'],
    constituency: nationalPerson[i]['const_name'],
    candidate: nationalPerson[i]['cand_name'],
    party: nationalPerson[i]['party_name'],
    img: nationalPerson[i]['cand_pic'] 
    };
    var leadingBlogElement = "";
    var spanElement = "<span>" + personailty.constituency + "</span>";
    var leadings = "<p>" + personailty.leadings + "</p>";
    if (personailty.leadings.toLowerCase() == "lead") {
    leadingBlogElement = "<div class='leading-blog'>" + leadings + spanElement + "</div>";
    }else if (personailty.leadings.toLowerCase() == "won") {
    leadingBlogElement = "<div class='won-blog'>" + leadings + spanElement + "</div>";
    } else if (personailty.leadings.toLowerCase() == "trailing") {
    leadingBlogElement = "<div class='trailing-blog'>" + leadings + spanElement + "</div>";
    } else if (personailty.leadings.toLowerCase() == "lost") {
    leadingBlogElement = "<div class='lost-blog'>" + leadings + spanElement + "</div>";
    } else {
    leadingBlogElement = "<div class='lost-blog'>" + leadings +spanElement + "</div>";
    }
    var otherSpanElement = "<span>" + personailty.party + "</span>";
    var heder4 = "<h4> " + personailty.candidate + " | " + otherSpanElement + "</h4>";
    var secDiv = "<div class='pers-blg-text col-md-9 col-sm-9 col-xs-9'>" + heder4 + leadingBlogElement + "</div>";
    var img = '<img id="vip-image" src="https://jh-vip-images.s3.ap-south-1.amazonaws.com/'+personailty.img+'.jpg" alt="">';
    var firstDiv = "<div class='img-blg col-md-3 col-sm-3 col-xs-3'>" + img + "</div>";
    var anc = "<a href='#' class='personalities-blg clearfix'>" + firstDiv + secDiv + "</div>";
    
    CombinedHTML = CombinedHTML + anc;
    
    }
    $("#nationalPersonalities").html(CombinedHTML);
    
    $('.img-blg img').off('error').on('error',function(){
    $(this).attr('src','https://etvelection.s3.ap-south-1.amazonaws.com/vipimages/common.jpg')
    });
    });
    };

// function getVipPerson() {
//     $.getJSON(stateWiseResUrl, function(successdata) {
//         var PartyInfo_statewise = successdata.results;
//         var nationalPersonVIP = successdata.results;
//         var CombinedHTMLVIP = '';
//         var leadingsVIP = "";
//         var leadingBlogElementVIP = "";
//         for (var j = 0; j <= nationalPersonVIP.length - 1; j++) {
//             var personailtyVIP = {
//                 img: nationalPerson[i]['cand_pic'],
//                 candidate: nationalPerson[i]['cand_name'],
//                 party: nationalPerson[i]['party_name'],
//                 leadings: nationalPerson[i]['status'],
//                 constituency: nationalPerson[i]['const_name']
//             };
//             var spanElementVIP = "<span>" + personailtyVIP.constituency + "</span>";
//             if (personailtyVIP.leadings.toLowerCase() == "lead") {
//                 leadingsVIP = "<p>" + personailtyVIP.leadings + "<i class='fa fa-thumbs-up'>" + "</i>" + "</p>";
//                 leadingBlogElementVIP = "<div class='vip-leading'>" + leadingsVIP + spanElementVIP + "</div>";
//             }else if (personailtyVIP.leadings.toLowerCase() == "won") {
//                 leadingsVIP = "<p>" + personailtyVIP.leadings + "<i class='fa fa-thumbs-up'>" + "</i>" + "</p>";
//                 leadingBlogElementVIP = "<div class='vip-leading vip-won'>" + leadingsVIP + spanElementVIP + "</div>";
//             }else if (personailtyVIP.leadings.toLowerCase() == "trailing") {
//                 leadingsVIP = "<p>" + personailtyVIP.leadings + "<i class='fa fa-thumbs-down'>" + "</i>" + "</p>";
//                 leadingBlogElementVIP = "<div class='vip-leading vip-trailing'>" + leadingsVIP + spanElementVIP + "</div>";
//             } else{
//                 leadingBlogElementVIP = "<div class='vip-leading vip-trailing'>" + spanElementVIP + "</div>";
//             }

//             var stElementVIP = "<strong>" + personailtyVIP.candidate + "</strong>";
//             var paraVIP = "<p> " + stElementVIP + " | " + personailtyVIP.party + "</p>";
//             var secDivVIP = "<div class='state-vip-cont clearfix'>" + paraVIP + leadingBlogElementVIP + "</div>";
//             var imgVIP = '<img src="'+personailtyVIP.img+'" alt="">';
//             var firstDivVIP = "<div href='#' class='vip-img'>" + imgVIP + "</div>";
//             var ancVIP = "<a href='#' class='states-vip-blog clearfix'>" + firstDivVIP + secDivVIP + "</div>";
//             CombinedHTMLVIP = CombinedHTMLVIP + ancVIP;
//         }
//      /*   $("#vipCandidates").html(CombinedHTMLVIP);
//         $('.vip-img img').off('error').on('error',function(){
//         $(this).attr('src','https://etvelection.s3.ap-south-1.amazonaws.com/vipimages/common.jpg')            
//         });
//        $('.img-blg img').off('error').on('error',function(){
//             $(this).attr('src','https://etvelection.s3.ap-south-1.amazonaws.com/vipimages/common.jpg')            
//         });*/
//     });
// }

function onChangeStates(val) {
    if(val)
    {
    $('#state-tg').empty();
    if ($.isNumeric(val)) {
        stateWiseResUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateVIP + val;
    }
    stateResBind(stateWiseResUrl);
    getVipPerson();
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}
}
/*
function onChangeConstWise(val) {
    if ($.isNumeric(val)) {
        stateConstUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency + val;
    } else {
        stateConstUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency;
    }
    constiResBind(stateConstUrl);
}
*/
// function stateResBind(url) {
//     const tbody = document.querySelector("#state-ap > tbody");
//     $.getJSON(url,
//         function(successdata) {
//             while (tbody.firstChild) {
//                 tbody.removeChild(tbody.firstChild);
//             }
//             CombinedHTMLTable = '';
//             var stateWiseTotal = 0;
//             for (var j = 0; j <= successdata.results.length - 1; j++) {
//                 var tr = "<tr>" + "<td>" + successdata.results[j]['party_name'] + "</td>" +
//                     "<td>" + successdata.results[j]['lead'] + "</td>" +
//                     "<td>" + successdata.results[j]['won'] + "</td>" +
//                     "<td>" + successdata.results[j]['total'] + "</td>" +
//                     "<td>" + successdata.results[j]['gain+'] + "</td>" +
//                     "<td>" + successdata.results[j]['loss-'] + "</td>" + "</tr>";
//                 CombinedHTMLTable = CombinedHTMLTable + tr;
//                 stateWiseTotal = stateWiseTotal + parseInt(successdata.results[j]['total']);
//             }
//             $("#StateWiseData").html(CombinedHTMLTable);
//             totalCount(successdata, stateWiseTotal)
//         });

// }

function totalCount(successdata, stateWiseTotal){
    var totalCountStateWise = successdata.results[0].TotalConstituency;
    document.getElementById("stateWiseTotal").textContent = parseInt(stateWiseTotal) +"/"+ parseInt(totalCountStateWise);
}

function callAPiEveryMinute(){    
    stateConstUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency ;
    // stateWiseResUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateVIP + $('#stateWiseOption').val();;
    getconstiResBind(stateConstUrl);
    getNationalPerson();
    getLokSabhaHighChart();//calling loksabha(jharkhand elections) everyminute
    // stateResBind(stateWiseResUrl);
    // getVipPerson();
}

// Jharkhand Constituency function
function getconstiResBind(url) {
    const tbody = document.querySelector("#AP_Constituency > tbody");
    $.getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var tr;
            for (var j = 0; j <= successdata.results.length - 1; j++) {
                if (successdata.results[j]['status'].toLowerCase() == "lead") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='leading-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else if (successdata.results[j]['status'].toLowerCase() == "won") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='won-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else if (successdata.results[j]['status'].toLowerCase() == "lost") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='lost-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='trailing-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
            }
            $("#constituency_tbody").html(CombinedHTMLTable);
            $("#tdSearch").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#AP_Constituency tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
}

// function atateAssembly(){
//     $.getJSON("http://13.127.2.47/web_api/website/vipcandidates_wonlead.php?language=ENGLISH&notif_id=11", function(successdata) {
//             CombinedAPTable = '';
//             var apAssemblyTotalLead = 0, apAssemblyTotalWon = 0, apAssemblyTotalTotal = 0;
//             for (var j = 0; j <= successdata.results.length - 1; j++) {
//                 var tr = "<tr>" + "<td>" + successdata.results[j]['party_name'] + "</td>" +
//                     "<td>" + successdata.results[j]['lead'] + "</td>" +
//                     "<td>" + successdata.results[j]['won'] + "</td>" +
//                     "<td>" + successdata.results[j]['total'] + "</td>" + "</tr>";
//                     CombinedAPTable = CombinedAPTable + tr;
//                     apAssemblyTotalLead = apAssemblyTotalLead + parseInt(successdata.results[j]['lead']);
//                     apAssemblyTotalWon = apAssemblyTotalWon + parseInt(successdata.results[j]['won']);
//                     apAssemblyTotalTotal = apAssemblyTotalTotal + parseInt(successdata.results[j]['total']);
//             }
//             $("#apAssembly").html(CombinedAPTable);
//             $("#apAssemblyTotalLead").html(apAssemblyTotalLead);
//             $("#apAssemblyTotalWon").html(apAssemblyTotalWon);
//             $(".apAssemblyTotalTotal").html(apAssemblyTotalTotal+"/175");
//         });
//        /* $.getJSON("https://rut.api.etvbharat.com/ERLIVE/ebapi/mp_statewise_vipcandidate.php?language=te&state=38", function(successdata) {
//             CombinedAPTable = '';
//             var odAssemblyTotalLead = 0, odAssemblyTotalWon = 0, odAssemblyTotalTotal = 0;
//             for (var j = 0; j <= successdata.results.length - 1; j++) {
//                 var tr = "<tr>" + "<td>" + successdata.results[j]['party_name'] + "</td>" +
//                     "<td>" + successdata.results[j]['lead'] + "</td>" +
//                     "<td>" + successdata.results[j]['won'] + "</td>" +
//                     "<td>" + successdata.results[j]['total'] + "</td>" + "</tr>";
//                     CombinedAPTable = CombinedAPTable + tr;
//                     odAssemblyTotalLead = odAssemblyTotalLead + parseInt(successdata.results[j]['lead']);
//                     odAssemblyTotalWon = odAssemblyTotalWon + parseInt(successdata.results[j]['won']);
//                     odAssemblyTotalTotal = odAssemblyTotalTotal + parseInt(successdata.results[j]['total']);
//             }
//             $("#odAssembly").html(CombinedAPTable);
//             $("#odAssemblyTotalLead").html(odAssemblyTotalLead);
//             $("#odAssemblyTotalWon").html(odAssemblyTotalWon);
//             $(".odAssemblyTotalTotal").html(odAssemblyTotalTotal+"/146");
//         });*/
// }
// atateAssembly();

function getCorpTotal(){
    const url="http://13.127.2.47/web_api/website/muncorp_ts20_website/muncipalwise_party_tally.php?language=english";
    getJSON(url, function(result){
        console.log(chartArray);
        var trsTotal =0, bjpTotal=0, incTotal=0, mimTotal=0, othTotal=0;
        for (var i = 0; i <= result.results.length - 1; i++) {
            var partyInfoArr = result.results[i];
            chartArray.push([partyInfoArr["corporation_name"]]);
            trsTotal += parseInt(partyInfoArr["partyname_trs"]);
            bjpTotal += parseInt(partyInfoArr["partyname_inc"]);
            incTotal += parseInt(partyInfoArr["partyname_bjp"]);
            mimTotal += parseInt(partyInfoArr["partyname_mim"]);
            othTotal += parseInt(partyInfoArr["others"]);
        }
        $("#trsTotal").html(trsTotal);
        $("#bjpTotal").html(bjpTotal);
        $("#incTotal").html(incTotal);
        $("#mimTotal").html(mimTotal);
        $("#othTotal").html(othTotal);
    });
}

$(document).ready(function() {
    // $('#partyWiseResults').DataTable(partyWiseResultsConfig);
    $('#corpPartyTally').DataTable(corpPartyTallyConfig);
    $('#mPartyTally').DataTable(mPartyTallyConfig);
    getLiveStateNews();
    getCorpTotal();
    //atateAssembly();
    getLanguageState(1,'stateWiseOption')
    getLanguageState(1,'constituencyWise')
    getLokSabhaHighChart();
    getconstiResBind();
    getNationalPerson();

    /*
    var test =getLiveStreamURL();
    var player='<iframe style="width:100%;" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';
    $('#test-player').html(player);
    $("#divPlayer").attr('src' , test);
    //livedebate
    //var test =getLiveDebateurl;
    var player1='<iframe style="width:100%;" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';
    $('#test-player1').html(player1);
    $("#divPlayer").attr('src' , test);
*/

    // setInterval(callAPiEveryMinute, 5000);
    // //setInterval(function(){location.href = location.href},30000);
    // setInterval(function(){
    //     // $('#lokSabhaEresult').DataTable(lokSabhaEresultConfig);
    // },5000);
});