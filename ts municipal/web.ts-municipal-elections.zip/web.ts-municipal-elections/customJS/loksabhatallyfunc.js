var allParty = [],allPartyValue = [], arrOfHC = [], chartArray = [], totalwards=0, sumTRS =0, sumBJP=0, sumINC=0, sumMIM=0, sumOthers=0, stateWiseResDropDef = 33;
var stateWiseResUrl = "http://13.127.2.47/web_api/website/partywise_wonlead_total.php?language=ENGLISH&notif_id=11";
var stateConstUrl = "http://13.127.2.47/web_api/website/statewise_const_tally.php?language=ENGLISH&notif_id=11";
var getName;

var appData = {
    apiConfig: {
        baseURL: 'http://13.127.2.47/web_api/website/',
        suffixes: {
            getState: 'getStates.php',
            corpPartyTally: 'muncorp_ts20_website/corporationwise_party_tally.php?language=english',
            mPartyTally: 'muncorp_ts20_website/muncipalwise_party_tally.php?language=english',
            resultType: '?electionType='
        },
    },
}

// var corpPartyTallyConfig = {
//     "ajax": {
//         url: appData.apiConfig.baseURL + appData.apiConfig.suffixes.corpPartyTally,
//         dataSrc: 'totalresults'
//     },
//     "bPaginate": false,
//     "aaSorting": [],
//     "columns": [{
//         "data": "corporation_name"
//     },
//     // {
//     //     "data": "totalwards"
//     // },
//     {
//         "data": "partyname_trs"
//     },
//     {
//         "data": "partyname_inc"
//     },
//     {
//         "data": "partyname_bjp"
//     },
//     {
//         "data": "partyname_mim"
//     },
//     {
//         "data": "others"
//     }
//   ]
// };

// var mPartyTallyConfig = {
//     "ajax": {
//         url: appData.apiConfig.baseURL + appData.apiConfig.suffixes.mPartyTally,
//         dataSrc: 'totalresults'
//     },
//     "bPaginate": false,
//     "aaSorting": [],
//     "columns": [{
//         "data": "muncipal_name"
//     },
//     // {
//     //     "data": "totalwards"
//     // },
//     {
//         "data": "partyname_trs"
//     },
//     {
//         "data": "partyname_inc"
//     },
//     {
//         "data": "partyname_bjp"
//     },
//     {
//         "data": "partyname_mim"
//     },
//     {
//         "data": "others"
//     }
//   ]
// };

function getJSON(url, successCallback) {
    $.getJSON(url, function(response) {
        successCallback(response);
    });
}

function getLiveStreamURL()
{
    var parentURL = document.referrer;
    //var parentURL = 'https://www.etvbharat.com/bengali/kerala';
    var temp = parentURL.split('/');
    var lang = temp[4];
    var stremingURLs = {
        "andhra-pradesh":"https://d1lqvjyfwvyj07.cloudfront.net/out/v1/d54651fa806648719a92727a661fa0d0/ETVB_CF_AP_NewsTime.m3u8",
        "assam":"https://etvbharatlive8.akamaized.net/hls/live/710674/assam/index.m3u8",
        "bihar":"https://etvbharatlive3.akamaized.net/hls/live/710666/bihar/index.m3u8",
        "chhattisgarh":"https://d2lkimnyxc1ji8.cloudfront.net/out/v1/cadefd8c8bff49d4a3ef38c1b3bf6a31/ETVB_CF_CG_NewsTime.m3u8",
        "delhi":"https://d29q6tdfij96f1.cloudfront.net/out/v1/94b12003316c4d6c9721a1508b0d1bac/ETVB_CF_DL_NewsTime.m3u8",
        "gujarat":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/04fee298badd4ea087aa4b68f4a8c034/ETVB_BG_GJ_NewsTime.m3u8",
        "haryana":"https://d3ejgzjh1qxqqq.cloudfront.net/out/v1/6d44b1b671d548a6bc95edea325b8413/ETVB_CF_HR_NewsTime.m3u8",
        "himachal-pradesh":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/a64cd2ff63e14792a4783b6d458ed5ab/ETVB_BG_HP_NewsTime.m3u8",
        "jharkhand":"https://etvbharatlive2.akamaized.net/hls/live/710296/jharkhand/index.m3u8",
        "jammu-and-kashmir":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "karnataka":"https://etvbharatlive5.akamaized.net/hls/live/710671/kannada/index.m3u8",
        "kerala":"https://etvbharatlive7.akamaized.net/hls/live/710673/kerala/index.m3u8",
        "maharashtra":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/bd4b06bb4ff24d938c3942ee89b1126d/ETVB_BG_MH_NewsTime.m3u8",
        "madhya-pradesh":"https://d1i5fpe095d43k.cloudfront.net/out/v1/16a901263bf7402e9cb7ff4b94fa5bfd/ETVB_CF_MP_NewsTime.m3u8",
        "english":"https://d5i7xalz199bi.cloudfront.net/out/v1/770fb77abc5d4ef487fc8b8b38d60510/ETVB_CF_EN_NewsTime.m3u8",
        "urdu":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "odisha":"https://etvbharatlive.akamaized.net/hls/live/707618/odisha/index.m3u8",
        "punjab":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/68eee6155d904f199aad20af043f9003/ETVB_BG_PB_NewsTime.m3u8",
        "rajasthan":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/0703d0f945c64e15aef72cd11fd54668/ETVB_BG_RJ_NewsTime.m3u8",
        "tamil-nadu":"https://dfae28bzu51al.cloudfront.net/out/v1/ee7ba7ef70fc4005a3992a2c0e8336aa/ETVB_CF_TN_NewsTime.m3u8",
        "telangana":"https://d1q8rg3smbsux8.cloudfront.net/out/v1/c7849afc704b478fb86a9e2caac3854a/ETVB_CF_TS_NewsTime.m3u8",
        "uttar-pradesh":"https://etvbharatlive6.akamaized.net/hls/live/710672/uttarPradesh/index.m3u8",
        "uttarakhand":"https://etvbharatlive1.akamaized.net/hls/live/710294/uttarakhand/index.m3u8",
        "west-bengal":"https://etvbharatlive9.akamaized.net/hls/live/710675/westBengal/index.m3u8"
    }
    if(lang)
    {
        var url = stremingURLs[lang.toLowerCase()];
        if(url)
            return url;
            console.log(url);
    }
    return stremingURLs['english'];
}


function getLanguageState() {
    getJSON("http://13.127.2.47/web_api/website/muncorp_ts20_website/getmunicipalities.php", function(getStatesresult) {
        renderLanguageState(createDropdownHTML(getStatesresult, 'state_id', 'state_name'));
         renderConstituencyState(createDropdownHTML(getStatesresult, 'muncipal_id', 'muncipal_name'));
    });
    getJSON("http://13.127.2.47/web_api/website/muncorp_ts20_website/getcorporations.php", function(getcorpresult){
        renderConstituencyState1(createDropdownHTML(getcorpresult, 'corporation_id', 'corporation_name'));
    })
}


function createDropdownHTML(incomingData, idKey, displayKey) {
    var option = "";
    for (var l = 0; l <= incomingData.results.length - 1; l++) {
        option += '<option value="' + incomingData.results[l][idKey] + '">' + incomingData.results[l][displayKey] + '</option>';
    }
    return option;
}


function renderConstituencyState(option) {
    document.getElementById('constituencyWise');
    $("#constituencyWise").empty();
    document.getElementById('constituencyWise').innerHTML = option;
    $(".constit-drop option").each(function() {
        if ($(this).text() == "")
            $(this).attr("selected", "selected");
    });
}




function renderConstituencyState1(option) {
    document.getElementById('constituencyWise3');
    $("#constituencyWise3").empty();
    document.getElementById('constituencyWise3').innerHTML = option;
    $(".constit-drop option").each(function() {
        if ($(this).text() == "")
            $(this).attr("selected", "selected");
    });
}


 function renderLanguageState(ele,option) {
   
    ele.innerHTML = option;
    var exists = false;
    $(ele).find('option').each(function(){
        if (this.value == stateWiseResDropDef) {
            exists = true;
            return false;
        }
    });
    if(exists){
    $(ele).val(stateWiseResDropDef);
    }
    $(ele).trigger("change");
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}



//Jharkhand tally function

function renderLokSabhaChart(arrOfHC, sumTRS, sumBJP, sumINC, sumMIM, sumOthers) {
    // $("#sum1").html(totalwards);
    $("#sumTRS").html(sumTRS);
    $("#sumBJP").html(sumBJP);
    $("#sumINC").html(sumINC);
    $("#sumMIM").html(sumMIM);
    $("#sumOthers").html(sumOthers);
    // $(".sumTotal").html(sumTotal+"/"+"81");


    Highcharts.chart('tally_lok_sabha', {
        chart: {
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: '',
            align: 'center',
            verticalAlign: 'middle',
            y: 50
        },
        tooltip: {
            pointFormat: '<b>{point.percentage:.1f}</b>'
        },
        plotOptions: {
            pie: {
                dataLabels: {
                    enabled: true,
                    distance: -70,
                    style: {
                        fontWeight: 'bold',
                        color: 'black'
                    }
                },
                startAngle: -90,
                endAngle: 90,
                center: ['50%', '50%']
            }
        },

        colors: ["#ff5429", "#00311f", "#128548", "#0255c7", "#ff0000", "#9f0606", "#db7b03", "#41ac38", "#8d8d8d", "#27a4ff"],
        series: [{
            type: 'pie',
            name: '',
            innerSize: '50%',
            data: arrOfHC
        }]
    });
};

// Corporation table data
function getCorpParty() {
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.corpPartyTally, function(result) {
        console.log(chartArray);
        CombinedHTMLTable='';
        var tr;
        for (var j = 0; j <= result.totalresults.length - 1; j++) {
        var tr = "<tr>" + "<td>" + result.totalresults[j]['corporation_name'] + "</td>" +
        // "<td>" + result.totalresults[j]['totalwards'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_trs'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_bjp'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_inc'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_mim'] + "</td>" +
        "<td>" + result.totalresults[j]['others'] + "</td>" + "</tr>";
    CombinedHTMLTable = CombinedHTMLTable + tr;
    // stateWiseTotal = stateWiseTotal + parseInt(result.totalresults[j]['Total']);
}
$("#corpPartyData").html(CombinedHTMLTable);
    });
}
// Municipality table data
function getMParty() {
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.mPartyTally, function(result) {
        console.log(chartArray);
        CombinedHTMLTable='';
        var tr;
        for (var j = 0; j <= result.totalresults.length - 1; j++) {
        var tr = "<tr>" + "<td>" + result.totalresults[j]['muncipal_name'] + "</td>" +
        // "<td>" + result.totalresults[j]['totalwards'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_trs'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_bjp'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_inc'] + "</td>" +
        "<td>" + result.totalresults[j]['partyname_mim'] + "</td>" +
        "<td>" + result.totalresults[j]['others'] + "</td>" + "</tr>";
    CombinedHTMLTable = CombinedHTMLTable + tr;
    // stateWiseTotal = stateWiseTotal + parseInt(result.totalresults[j]['Total']);
}
$("#mPartyData").html(CombinedHTMLTable);
    });
}

// Corporation tally function
function getCorpPartyTally() {
    //highchart
    //Tally Jharkhand
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.corpPartyTally, function(result) {
        console.log(chartArray);
        var arrOfHC=0, sumTRS =0, sumBJP=0, sumINC=0, sumMIM=0, sumOthers=0;
        for (var i = 0; i <= result.totalresults.length - 1; i++) {
            var partyInfoArr = result.totalresults[i];
            chartArray.push([partyInfoArr["corporation_name"]]);
            // totalwards += parseInt(partyInfoArr["totalwards"]);
            sumTRS += parseInt(partyInfoArr["partyname_trs"]);
            sumBJP += parseInt(partyInfoArr["partyname_bjp"]);
            sumINC += parseInt(partyInfoArr["partyname_inc"]);
            sumMIM += parseInt(partyInfoArr["partyname_mim"]);
            sumOthers += parseInt(partyInfoArr["others"]);
        }
        var arrOfHC = [chartArray[0],chartArray[7],chartArray[5],chartArray[6],chartArray[4],chartArray[2],chartArray[3],chartArray[1]];
        // renderLokSabhaChart(arrOfHC, sumTRS, sumBJP, sumINC, sumMIM, sumOthers);
        // $("#sum1").html(totalwards);
        $("#sumTRS").html(sumTRS);
        $("#sumBJP").html(sumBJP);
        $("#sumINC").html(sumINC);
        $("#sumMIM").html(sumMIM);
        $("#sumOthers").html(sumOthers);

        $("#corpTSearch").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#corpPartyTally tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
}

// Municipal tally function
function getMPartyTally() {
    //highchart
    //Tally Jharkhand
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.mPartyTally, function(result) {
        console.log(chartArray);
        var totalwards=0, sumTRS =0, sumBJP=0, sumINC=0, sumMIM=0, sumOthers=0;
        for (var i = 0; i <= result.totalresults.length - 1; i++) {
            var partyInfoArr = result.totalresults[i];
            chartArray.push([partyInfoArr["muncipal_name"]]);
            // totalwards += parseInt(partyInfoArr["totalwards"]);
            sumTRS += parseInt(partyInfoArr["partyname_trs"]);
            sumBJP += parseInt(partyInfoArr["partyname_bjp"]);
            sumINC += parseInt(partyInfoArr["partyname_inc"]);
            sumMIM += parseInt(partyInfoArr["partyname_mim"]);
            sumOthers += parseInt(partyInfoArr["others"]);
        }
        var arrOfHC = [chartArray[0],chartArray[7],chartArray[5],chartArray[6],chartArray[4],chartArray[2],chartArray[3],chartArray[1]];
        // renderMTally(arrOfHC, totalwards, sumTRS, sumBJP, sumINC, sumMIM, sumOthers);
        // $("#sum2").html(totalwards);
        $("#msumTRS").html(sumTRS);
        $("#msumBJP").html(sumBJP);
        $("#msumINC").html(sumINC);
        $("#msumMIM").html(sumMIM);
        $("#msumOthers").html(sumOthers);

        $("#mTSearch").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#mPartyTally tr").filter(function() {
                $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
}

function onChangeStates(val) {
    if(val)
    {
    $('#state-tg').empty();
    if ($.isNumeric(val)) {
        stateWiseResUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateVIP + val;
    }
    stateResBind(stateWiseResUrl);
    getVipPerson();
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}
}
function onChangeConstWise(val) {
    if ($.isNumeric(val)) {
        stateConstUrl = "http://13.127.2.47/web_api/website/muncorp_ts20_website/municipalwise_winning_candidate.php?language=english&municipal=" + val;
    } else {
        stateConstUrl = "http://13.127.2.47/web_api/website/muncorp_ts20_website/municipalwise_winning_candidate.php?language=english&municipal=64";
    }
    constiResBind(stateConstUrl);
}

function onChangeConstWise3(val) {
    if ($.isNumeric(val)) {
        stateConstUrl3 = "http://13.127.2.47/web_api/website/muncorp_ts20_website/corporationwise_winning_candidate.php?language=english&corporation=" + val;
    } else {
        stateConstUrl3 = "http://13.127.2.47/web_api/website/muncorp_ts20_website/corporationwise_winning_candidate.php?language=english&corporation=1";
    }
    constiResBind1(stateConstUrl3);
}

function stateResBind() {
    const tbody = document.querySelector("#state-ap > tbody");
    $.getJSON(url,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var stateWiseTotal = 0;
            for (var j = 0; j <= successdata.results.PartyInfo.length - 1; j++) {
                var tr = "<tr>" + "<td>" + successdata.results.PartyInfo[j]['Party'] + "</td>" +
                    "<td>" + successdata.results.PartyInfo[j]['Lead'] + "</td>" +
                    "<td>" + successdata.results.PartyInfo[j]['Won'] + "</td>" +
                    "<td>" + successdata.results.PartyInfo[j]['Total'] + "</td>" +
                    "<td>" + successdata.results.PartyInfo[j]['Gain'] + "</td>" +
                    "<td>" + successdata.results.PartyInfo[j]['Loss'] + "</td>" + "</tr>";
                CombinedHTMLTable = CombinedHTMLTable + tr;
                stateWiseTotal = stateWiseTotal + parseInt(successdata.results.PartyInfo[j]['Total']);
            }
            $("#StateWiseData").html(CombinedHTMLTable);
            totalCount(successdata, stateWiseTotal)
        });

}

function totalCount(successdata, stateWiseTotal){
    var totalCountStateWise = successdata.results.PartyInfo[0].TotalConstituency;
    document.getElementById("stateWiseTotal").textContent = parseInt(stateWiseTotal) +"/"+ parseInt(totalCountStateWise);
}

// function callAPiEveryMinute(){
//     stateConstUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency + $('#constituencyWise').val();
//     stateWiseResUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateVIP + $('#stateWiseOption').val();;
//     constiResBind(stateConstUrl);
//     stateResBind(stateWiseResUrl);
//     getVipPerson();
    
// }
function constiResBind1(url) {
    const tbody = document.querySelector("#AP_Constituency3 > tbody");
    $.getJSON(url,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var tr;
            for (var j = 0; j <= successdata.results.length - 1; j++) {
                if (successdata.results[j]['status'].toLowerCase() == "lead") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='leading-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else if (successdata.results[j]['status'].toLowerCase() == "won") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='won-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else if (successdata.results[j]['status'].toLowerCase() == "lost") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='lost-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='trailing-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
            }
            // $("#onChangeConstWise").html(CombinedHTML);
            $("#constituency_tbody3").html(CombinedHTMLTable);
            $("#corpESearch").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#AP_Constituency3 tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
}

function constiResBind(url) {
    const tbody = document.querySelector("#AP_Constituency1 > tbody");
    $.getJSON(url,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var tr;
            for (var j = 0; j <= successdata.results.length - 1; j++) {
                if (successdata.results[j]['status'].toLowerCase() == "lead") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='leading-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else if (successdata.results[j]['status'].toLowerCase() == "won") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='won-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else if (successdata.results[j]['status'].toLowerCase() == "lost") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='lost-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['cand_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='trailing-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
            }
            // $("#onChangeConstWise").html(CombinedHTML);
            $("#constituency_tbody").html(CombinedHTMLTable);
            $("#mESearch").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#AP_Constituency1 tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
}

$(document).ready(function() {
    // $('#corpPartyTally').DataTable(corpPartyTallyConfig);
    // $('#mPartyTally').DataTable(mPartyTallyConfig);
    getCorpParty();
    getMParty();
    getCorpPartyTally();
    getMPartyTally();
    // getLiveStateNews();
    getLanguageState();
    onChangeConstWise();
    onChangeConstWise3();

    var test =getLiveStreamURL();
    var player='<iframe style="width: 100%; height: 315px" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';    $('#test-player').html(player);
    $('#test-player').html(player);
    $("#divPlayer").attr('src' , test);


    setInterval(callAPiEveryMinute, 5000);
    //setInterval(function(){location.href = location.href},30000);
    setInterval(function(){
        // $('#lokSabhaEresult').DataTable(lokSabhaEresultConfig);
    },5000);
});