var allParty = [],allPartyValue = [], arrOfHC = [], chartArray = [],sumAllPartyValue = 0,sumAllPartyValueLead = 0, sumAllPartyValueWon = 0, stateWiseResDropDef = 33;
var stateWiseResUrl = "http://13.127.2.47/web_api/website/partywise_wonlead_total.php?language=ENGLISH&notif_id=11";
var stateConstUrl = "http://13.127.2.47/web_api/website/statewise_const_tally.php?language=ENGLISH&notif_id=11";
var getName;

var appData = {
    apiConfig: {
        // baseURL: 'http://13.127.2.47/web_api/website/dl_2020/',
        baseURL: 'https://mcapi.etvbharat.com/web_api/website/dl_2020/',
        suffixes: {
            getState: 'getStates.php',
            partyWiseResults: 'partywise_wonlead_total.php?language=english',
            stateVIP: 'vipcandidates_wonlead.php?language=english',
            stateConstituency: 'statewise_const_tally.php?language=english',
            nationalPerson: 'vipcandidates_wonlead.php?language=english',
            resultType: '?electionType='
        },
    },
}

var partyWiseResultsConfig = {
    "ajax": {
        url: appData.apiConfig.baseURL + appData.apiConfig.suffixes.partyWiseResults,
        dataSrc: 'results'
    },
    "bPaginate": false,
    "aaSorting": [],
    "columns": [{ 
        "data": "party_name"
    },
    {
        "data": "lead"
    },
    {
        "data": "won"
    },
    {
        "data": "total"
    }
  ]
};

var lokSabhaEresultConfig = {
    "ajax": {
        url:appData.apiConfig.baseURL + appData.apiConfig.suffixes.partyWiseResults,
        dataSrc: 'results'
    },
    "bPaginate": false,
    "aaSorting": [],
    "destroy": true,
    "columns": [{
        "data": "party_name"
    },
    {
        "data": "lead"
    },
    {
        "data": "won"
    },
    {
        "data": "total"
    }
    ]
};

function getJSON(url, successCallback) {
    $.getJSON(url, function(response) {
        successCallback(response);
    });
}

function getLiveStreamURL()
{
    var parentURL = document.referrer;
    //var parentURL = 'https://www.etvbharat.com/bengali/kerala';
    var temp = parentURL.split('/');
    var lang = temp[4];
    var stremingURLs = {
        "andhra-pradesh":"https://d1lqvjyfwvyj07.cloudfront.net/out/v1/d54651fa806648719a92727a661fa0d0/ETVB_CF_AP_NewsTime.m3u8",
        "assam":"https://etvbharatlive8.akamaized.net/hls/live/710674/assam/index.m3u8",
        "bihar":"https://etvbharatlive3.akamaized.net/hls/live/710666/bihar/index.m3u8",
        "chhattisgarh":"https://d2lkimnyxc1ji8.cloudfront.net/out/v1/cadefd8c8bff49d4a3ef38c1b3bf6a31/ETVB_CF_CG_NewsTime.m3u8",
        "delhi":"https://d29q6tdfij96f1.cloudfront.net/out/v1/94b12003316c4d6c9721a1508b0d1bac/ETVB_CF_DL_NewsTime.m3u8",
        "gujarat":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/04fee298badd4ea087aa4b68f4a8c034/ETVB_BG_GJ_NewsTime.m3u8",
        "haryana":"https://d3ejgzjh1qxqqq.cloudfront.net/out/v1/6d44b1b671d548a6bc95edea325b8413/ETVB_CF_HR_NewsTime.m3u8",
        "himachal-pradesh":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/a64cd2ff63e14792a4783b6d458ed5ab/ETVB_BG_HP_NewsTime.m3u8",
        "jharkhand":"https://etvbharatlive2.akamaized.net/hls/live/710296/jharkhand/index.m3u8",
        "jammu-and-kashmir":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "karnataka":"https://etvbharatlive5.akamaized.net/hls/live/710671/kannada/index.m3u8",
        "kerala":"https://etvbharatlive7.akamaized.net/hls/live/710673/kerala/index.m3u8",
        "maharashtra":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/bd4b06bb4ff24d938c3942ee89b1126d/ETVB_BG_MH_NewsTime.m3u8",
        "madhya-pradesh":"https://d1i5fpe095d43k.cloudfront.net/out/v1/16a901263bf7402e9cb7ff4b94fa5bfd/ETVB_CF_MP_NewsTime.m3u8",
        "english":"https://d5i7xalz199bi.cloudfront.net/out/v1/770fb77abc5d4ef487fc8b8b38d60510/ETVB_CF_EN_NewsTime.m3u8",
        "urdu":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/baf7abc4aceb441abe16f4d636fb80cc/ETVB_BG_UR_NewsTime.m3u8",
        "odisha":"https://etvbharatlive.akamaized.net/hls/live/707618/odisha/index.m3u8",
        "punjab":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/68eee6155d904f199aad20af043f9003/ETVB_BG_PB_NewsTime.m3u8",
        "rajasthan":"https://etvbharat.pc.cdn.bitgravity.com/out/v1/0703d0f945c64e15aef72cd11fd54668/ETVB_BG_RJ_NewsTime.m3u8",
        "tamil-nadu":"https://dfae28bzu51al.cloudfront.net/out/v1/ee7ba7ef70fc4005a3992a2c0e8336aa/ETVB_CF_TN_NewsTime.m3u8",
        "telangana":"https://d1q8rg3smbsux8.cloudfront.net/out/v1/c7849afc704b478fb86a9e2caac3854a/ETVB_CF_TS_NewsTime.m3u8",
        "uttar-pradesh":"https://etvbharatlive6.akamaized.net/hls/live/710672/uttarPradesh/index.m3u8",
        "uttarakhand":"https://etvbharatlive1.akamaized.net/hls/live/710294/uttarakhand/index.m3u8",
        "west-bengal":"https://etvbharatlive9.akamaized.net/hls/live/710675/westBengal/index.m3u8"
    }
    if(lang)
    {
        var url = stremingURLs[lang.toLowerCase()];
        if(url)
            return url;
            console.log(url);
    }
    return stremingURLs['english'];
}

function getLanguageState(value, stateDdlID) {
    var ele = document.getElementById(stateDdlID);
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.getState+'?electionType='+value, function(getStatesresult) {
        renderLanguageState(ele,createDropdownHTML(getStatesresult, 'state_id', 'state_name'));
    });
}

function createDropdownHTML(incomingData, idKey, displayKey) {
    var option = "";
    for (var l = 0; l <= incomingData.results.length - 1; l++) {
        option += '<option value="' + incomingData.results[l][idKey] + '">' + incomingData.results[l][displayKey] + '</option>';
    }
    return option;
}

function renderLanguageState(ele,option) {
    ele.innerHTML = option;
    var exists = false;
    $(ele).find('option').each(function(){
        if (this.value == stateWiseResDropDef) {
            exists = true;
            return false;
        }
    });
    if(exists){
    $(ele).val(stateWiseResDropDef);
    }
    $(ele).trigger("change");
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}

//Jharkhand tally function

function renderLokSabhaChart(arrOfHC, sumAllPartyValue, sumAllPartyValueLead, sumAllPartyValueWon) {
    $("#sumAllPartyValueLead").html(sumAllPartyValueLead);
    $("#sumAllPartyValueWon").html(sumAllPartyValueWon);
    $(".sumAllPartyValue").html(sumAllPartyValue+"/"+"70");


    Highcharts.chart('tally_lok_sabha', {
        chart: {
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
            text: '',
            align: 'center',
            verticalAlign: 'middle',
            y: 50
        },
        tooltip: {
            pointFormat: '<b>{point.percentage:.1f}</b>'
        },
        plotOptions: {
            pie: {
                dataLabels: {
                    enabled: true,
                    distance: -70,
                    style: {
                        fontWeight: 'bold',
                        color: 'black'
                    }
                },
                startAngle: -90,
                endAngle: 90,
                center: ['50%', '50%']
            }
        },

        colors: ["#ff5429", "#00311f", "#128548", "#0255c7", "#ff0000", "#9f0606", "#db7b03", "#41ac38", "#8d8d8d", "#27a4ff"],
        series: [{
            type: 'pie',
            name: '',
            innerSize: '50%',
            data: arrOfHC
        }]
    });
};

// LiveNews function

function getLiveStateNews(){
    var test =getLiveStreamURL();
    var player='<iframe style="width: 100%; height: 300px" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0" allowFullScreen="true" class="tally-scroll" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test+'&thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&autoplay=true&mute=true&content_type=live"></iframe>';    $('#test-player').html(player);
    $("#divPlayer").attr('src' , test);

    $('#livenews').css('font-weight','600');
    $('#livedebate').css('color','white');
}

// LiveDebate function

function getLiveDebate() {
    var test1 ='https://dgt6f5s87pgbo.cloudfront.net/out/v1/dd6e383c67c44d20a41a358679edd9c7/ETVB_CF_JK_Live3.m3u8';
    var player='<iframe style="width:100%; height:300px;" id="live-player" class="liveplayer" allowfullscreen="true" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl='+test1+'&amp;thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&amp;autoplay=true&amp;mute=true&amp;content_type=live&amp;content_id=keralaml20181012194643400&amp;v=0.007124921779837923&amp;comscorec3=23&amp;state=kerala&amp;language=malayalam&amp;daistream=true" src="https://etvbharatimages.akamaized.net/player/etvbharat-staging/embed_etv.html?contenturl=https://etvbharatlive7.akamaized.net/hls/live/710673/kerala/index.m3u8&amp;thumbnailurl=https://etvwinvideo.akamaized.net/etv-bharat/images/placeholder.png&amp;autoplay=true&amp;mute=true&amp;content_type=live&amp;content_id=keralaml20181012194643400&amp;v=0.007124921779837923&amp;comscorec3=23&amp;state=kerala&amp;language=malayalam&amp;daistream=true"></iframe>';
    $('#test-player').html(player);
    $("#divPlayer").attr('src' , test1);

    $('#livedebate').css('font-weight','600');
    $('#livenews').css('color','white');

}

//Jharkhand tally function
function getLokSabhaHighChart() {
    getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.partyWiseResults, function(result) {
        console.log(chartArray);
        var sumAllPartyValue =0, sumAllPartyValueWon=0, sumAllPartyValueLead=0;
        for (var i = 0; i <= result.results.length - 1; i++) {
            var partyInfoArr = result.results[i];
            chartArray.push([partyInfoArr["party_name"], parseInt(partyInfoArr["total"])]);
            sumAllPartyValue += parseInt(partyInfoArr["total"]);
            sumAllPartyValueLead += parseInt(partyInfoArr["lead"]);
            sumAllPartyValueWon += parseInt(partyInfoArr["won"]);
        }
        var arrOfHC = [chartArray[0],chartArray[7],chartArray[5],chartArray[6],chartArray[4],chartArray[2],chartArray[3],chartArray[1]];
        renderLokSabhaChart(arrOfHC, sumAllPartyValue, sumAllPartyValueLead, sumAllPartyValueWon);
    });
}
// Jharkhand VIP Candidates
function getNationalPerson() {
    $.getJSON( appData.apiConfig.baseURL+appData.apiConfig.suffixes.stateVIP, function(success) {
    var nationalPerson = success.results;
    var CombinedHTML = '';
    for (var i = 0; i <= nationalPerson.length - 1; i++) {
    var personailty = {
    leadings: nationalPerson[i]['status'],
    constituency: nationalPerson[i]['const_name'],
    candidate: nationalPerson[i]['cand_name'],
    party: nationalPerson[i]['party_name'],
    img: nationalPerson[i]['cand_pic'] 
    };
    var leadingBlogElement = "";
    var spanElement = "<span>" + personailty.constituency + "</span>";
    var leadings = "<p>" + personailty.leadings + "</p>";
    if (personailty.leadings.toLowerCase() == "lead") {
    leadingBlogElement = "<div class='leading-blog'>" + leadings + spanElement + "</div>";
    }else if (personailty.leadings.toLowerCase() == "won") {
    leadingBlogElement = "<div class='won-blog'>" + leadings + spanElement + "</div>";
    } else if (personailty.leadings.toLowerCase() == "trailing") {
    leadingBlogElement = "<div class='trailing-blog'>" + leadings + spanElement + "</div>";
    } else if (personailty.leadings.toLowerCase() == "lost") {
    leadingBlogElement = "<div class='lost-blog'>" + leadings + spanElement + "</div>";
    } else {
    leadingBlogElement = "<div class='lost-blog'>" + leadings +spanElement + "</div>";
    }
    var otherSpanElement = "<span>" + personailty.party + "</span>";
    var heder4 = "<h4> " + personailty.candidate + " | " + otherSpanElement + "</h4>";
    var secDiv = "<div class='pers-blg-text col-md-9 col-sm-9 col-xs-9'>" + heder4 + leadingBlogElement + "</div>";
    var img = '<img id="vip-image" src="https://jh-vip-images.s3.ap-south-1.amazonaws.com/'+personailty.img+'" alt="">';
    var firstDiv = "<div class='img-blg col-md-3 col-sm-3 col-xs-3'>" + img + "</div>";
    var anc = "<a href='#' class='personalities-blg clearfix'>" + firstDiv + secDiv + "</div>";
    
    CombinedHTML = CombinedHTML + anc; 
    }
    $("#nationalPersonalities").html(CombinedHTML);
    
    $('.img-blg img').off('error').on('error',function(){
    $(this).attr('src','https://etvelection.s3.ap-south-1.amazonaws.com/vipimages/common.jpg')
    });
    });
    };

function onChangeStates(val) {
    if(val)
    {
    $('#state-tg').empty();
    if ($.isNumeric(val)) {
        stateWiseResUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateVIP + val;
    }
    stateResBind(stateWiseResUrl);
    getVipPerson();
    getName = $( "#stateWiseOption option:selected" ).text();
    $("#stateText").text(getName);
}
}

function totalCount(successdata, stateWiseTotal){
    var totalCountStateWise = successdata.results[0].TotalConstituency;
    document.getElementById("stateWiseTotal").textContent = parseInt(stateWiseTotal) +"/"+ parseInt(totalCountStateWise);
}

function callAPiEveryMinute(){    
    stateConstUrl = appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency ;
    getconstiResBind(stateConstUrl);
    getNationalPerson();
}

function callTallyEveryMinute(){    
    getLokSabhaHighChart();
}

// Jharkhand Constituency function
function getconstiResBind(url) {
    const tbody = document.querySelector("#AP_Constituency > tbody");
    $.getJSON(appData.apiConfig.baseURL + appData.apiConfig.suffixes.stateConstituency,
        function(successdata) {
            while (tbody.firstChild) {
                tbody.removeChild(tbody.firstChild);
            }
            CombinedHTMLTable = '';
            var tr;
            for (var j = 0; j <= successdata.results.length - 1; j++) {
                if (successdata.results[j]['status'].toLowerCase() == "lead") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='leading-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }else if (successdata.results[j]['status'].toLowerCase() == "won") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='won-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else if (successdata.results[j]['status'].toLowerCase() == "lost") {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='lost-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
                else {
                    tr = "<tr>" + "<td>" + successdata.results[j]['const_name'] + "</td>" +
                        "<td>" + successdata.results[j]['candidate_name'] + "</td>" +
                        "<td>" + successdata.results[j]['party_name'] + "</td>" +
                        "<td class='trailing-blog sorting_1'>" + "<p>" + successdata.results[j]['status'] + "</p>" + "</td>" + "</tr>";
                    CombinedHTMLTable = CombinedHTMLTable + tr;
                }
            }
            $("#constituency_tbody").html(CombinedHTMLTable);
            $("#tdSearch").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#AP_Constituency tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
}

var electionLanguage;
var electionadurl;

function addFunctionBottom(){

electionLanguage =  window.location.href.split('/')[3];

if(electionLanguage == 'hindi'){
    electionadurl = '<div class="add-space" id="div-gpt-ad-1576747522400-0" style="width: 300px; height: 250px;">' +
    // '<script>googletag.cmd.push(function() { googletag.display("div-gpt-ad-1576747522400-0"); }); </script>' +
    '</div>';
    document.getElementById("AddsBottom").innerHTML = electionadurl;
}
else{
    electionadurl = '<div class="add-space" id="div-gpt-ad-1581136601586-0" style="width: 300px; height: 250px;">' +
    // '<script>googletag.cmd.push(function() { googletag.display("div-gpt-ad-1581136913616-0"); }); </script>' +
    '</div>';
    document.getElementById("AddsBottom").innerHTML = electionadurl;
}
}

function addFunctionTop(){

electionLanguage = window.location.href.split('/')[3];

if(electionLanguage == 'hindi'){
    electionadurl = '<div class="add-space" id="div-gpt-ad-1576747571175-0" style="width: 300px; height: 250px;">' +
    // '<script>googletag.cmd.push(function() { googletag.display("div-gpt-ad-1576747571175-0"); }); </script>' +
    '</div>';
    document.getElementById("AddsTop").innerHTML = electionadurl;
}
else{
    electionadurl = '<div class="add-space" id="div-gpt-ad-1581136693108-0" style="width: 300px; height: 250px;">' +
    // '<script>googletag.cmd.push(function() { googletag.display("div-gpt-ad-1581136693108-0"); }); </script>' +
    '</div>';
    document.getElementById("AddsTop").innerHTML = electionadurl;
}
}












$(document).ready(function() {
    $('#lokSabhaEresult').DataTable(lokSabhaEresultConfig);
    getLiveStateNews();
    // getLanguageState(1,'stateWiseOption')
    // getLanguageState(1,'constituencyWise')
    getLokSabhaHighChart();
    getconstiResBind();
    getNationalPerson();
    setInterval(callAPiEveryMinute, 60000);
    setInterval(callTallyEveryMinute, 20000);
    setInterval(function(){
        $('#lokSabhaEresult').DataTable(lokSabhaEresultConfig);
    },20000);
    

    $('#livenews').click(function(){
        $(this).css('color','red');
        $(this).html('Live News');
        $('#livedebate').html('Live Debate');
        $('#livedebate').css('font-weight','400');
    });

    $('#livedebate').click(function(){
        $(this).css('color','red');
        $(this).html('Live Debate');
        $('#livenews').html('Live News');
        $('#livenews').css('font-weight','400');

    });
    addFunctionBottom();
    addFunctionTop();

    
});